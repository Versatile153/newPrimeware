<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
   
    <img width="150" src="{{ asset('/storage/images/TokBs8iPtC7dgLeJNNy0vKBV1BKn6rd1MFulWWPU.png/') }}" alt="">
   <img width="150" src="https://media.istockphoto.com/id/1371711142/photo/cheerful-young-people-walking-outside-talking-and-having-fun-mixed-race-friends-hanging-down.jpg?b=1&s=170667a&w=0&k=20&c=zqCdHO1KZplrR47NCd_JA-E0IFPUBxdqQ_PgDYRv014=" alt="">

</body>
</html>